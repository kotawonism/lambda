SELECT from_unixtime(timestamp/1000, 'Asia/Tokyo') AS JST,
       terminatingruleid,
       rulegrouplist,
       httprequest.clientip,
       httprequest.uri,
       httprequest.args,
       httprequest.httpmethod
FROM "waf-logs"
WHERE rulegrouplist like '%BLOCK%'