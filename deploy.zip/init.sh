#!/bin/bash

mkdir ./lib
pip3 install -r requirements.txt -t ./lib
